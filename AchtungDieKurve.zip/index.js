function AddPlayer() {
    if (players.length >= 7) {
        document.getElementById("add-player").disabled = true;
    }
    //players.push(document.getElementById("player-name").innerText);
    console.log("test");
}